Policy as code: centralize decisions (e.g., functorized policy module).
module type POLICY = sig
  val allow : jwt -> action:string -> resource:string -> bool
