(* KEYS[1]=bucket, ARGV[1]=capacity, ARGV[2]=refill_rate_per_s, ARGV[3]=now_ms *)
(* Returns 1 if allowed, 0 if limited *)
