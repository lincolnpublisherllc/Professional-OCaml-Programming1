let decode_trade (j: Yojson.Safe.t) : (trade, err) result =
  let open Result in
  let* sym = Json.get_string "sym" j |> Result.map_error (fun _ -> `Missing "sym") in
  let* qty = Json.get_int "qty" j |> Result.map_error (fun _ -> `Bad_number "qty") in
  let* px  = Json.get_float "px" j |> Result.map_error (fun _ -> `Bad_number "px") in
  let* ts  = Json.get_int "ts" j |> Result.map_error (fun _ -> `Bad_number "ts") in
  if qty < 0 || qty > 10_000 then Error (`Too_large ("qty", qty))
  else Ok { sym; qty; px; ts }
