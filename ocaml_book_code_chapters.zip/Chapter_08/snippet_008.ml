let handle_idempotent ~cache key process =
  Cache.claim_idempotency cache ~key ~payload:"1" ~ttl:3600 >>= function
  | false -> Cache.get cache key  (* return prior *)
  | true  -> process () >>= fun res ->
             Cache.setx cache ~key ~value:res ~ttl:3600 >|= fun () -> res
