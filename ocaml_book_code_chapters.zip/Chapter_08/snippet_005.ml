type jwt = { sub: string; aud: string; exp: int; scope: string list; tenant: string option }
type jwt_err = [ `Invalid_sig | `Expired | `Bad_aud | `Missing_claim of string ]
