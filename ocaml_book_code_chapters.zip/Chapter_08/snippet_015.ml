Validate early, type everything, keep errors as data.
