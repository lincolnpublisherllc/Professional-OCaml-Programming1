Eio + OCaml-TLS sketch (conceptual):
(* Pseudocode: in practice use libraries that load PEMs/certs properly *)
let tls_server ~cert ~key ~client_ca =
  Eio_tls.Server.create ~cert ~key ~client_auth:(`Required client_ca)
