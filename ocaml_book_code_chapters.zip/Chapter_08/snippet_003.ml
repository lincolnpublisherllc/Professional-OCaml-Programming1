type err =
  [ `Missing of string
  | `Bad_number of string
  | `Bad_enum of string
  | `Too_large of string * int
  ]
