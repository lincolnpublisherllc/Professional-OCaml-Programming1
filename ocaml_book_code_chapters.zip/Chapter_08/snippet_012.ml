type state = Closed | Open of float | Half_open
type breaker = { mutable state: state; failures: int ref; threshold: int; cooldown_s: float }
