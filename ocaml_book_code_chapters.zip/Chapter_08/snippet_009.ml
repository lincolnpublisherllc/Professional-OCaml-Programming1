  tenant text, key text, PRIMARY KEY (tenant, key),
  result jsonb, created_at timestamptz default now()
