let call br f =
  match br.state with
  | Open until_t when Unix.gettimeofday () < until_t ->
      Error `Open
  | Open _ | Half_open | Closed ->
      match f () with
      | Ok v -> br.state <- Closed; br.failures := 0; Ok v
      | Error e ->
          incr br.failures;
          if !(br.failures) >= br.threshold then
            br.state <- Open (Unix.gettimeofday () +. br.cooldown_s);
          Error e
