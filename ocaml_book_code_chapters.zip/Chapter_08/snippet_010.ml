let rec retry ~attempts ~sleep_ms ~f =
  f () >>= function
  | Ok v -> Lwt.return (Ok v)
  | Error e when attempts > 0 ->
      let jitter = Random.int (sleep_ms / 2) in
      Lwt_unix.sleep (float_of_int (sleep_ms + jitter) /. 1000.) >>= fun () ->
      retry ~attempts:(attempts-1) ~sleep_ms:(sleep_ms*2) ~f
  | Error e -> Lwt.return (Error e)
