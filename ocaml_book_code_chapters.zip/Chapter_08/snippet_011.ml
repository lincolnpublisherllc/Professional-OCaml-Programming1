8.5.2 Circuit breaker (closed → open → half-open)
