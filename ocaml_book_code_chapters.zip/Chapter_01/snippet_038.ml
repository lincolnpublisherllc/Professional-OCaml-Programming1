  "ocaml" {>= "5.2.1"}
  "dune"  {>= "3.11"}
  "cmdliner"
  "alcotest"
