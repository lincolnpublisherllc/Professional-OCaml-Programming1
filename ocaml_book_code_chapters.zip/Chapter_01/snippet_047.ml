Pin everything that affects builds: compiler, dune, system packages where possible.
