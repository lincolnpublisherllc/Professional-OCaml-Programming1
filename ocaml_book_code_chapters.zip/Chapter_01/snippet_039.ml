	opam switch create . 5.2.1 -y && eval "$$(opam env)" && opam install . --deps-only -y && opam lock .
