  release:
    needs: build
    if: startsWith(github.ref, 'refs/tags/')
    runs-on: ubuntu-22.04
    steps:
      - uses: actions/download-artifact@v4
        with: { name: acme-ubuntu-22.04-5.2.1, path: dist/linux }
      - uses: actions/download-artifact@v4
        with: { name: acme-macos-13-5.2.1, path: dist/macos }
      - name: Create GitHub Release
        uses: softprops/action-gh-release@v1
        with:
          files: |
            dist/linux/*
            dist/macos/*
