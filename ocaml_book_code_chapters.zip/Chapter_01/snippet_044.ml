Add .ocamlformat and run dune fmt.
