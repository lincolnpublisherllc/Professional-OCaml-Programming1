	dune build --profile release @install
