  build:
    strategy:
      matrix:
        os: [ubuntu-22.04, macos-13]
        ocaml: [5.2.1]
    runs-on: ${{ matrix.os }}
    steps:
      - uses: actions/checkout@v4
      - name: Set up OCaml
        uses: ocaml/setup-ocaml@v3
        with:
          ocaml-compiler: ${{ matrix.ocaml }}
          opam-depext: true
      - name: Cache opam
        uses: actions/cache@v4
        with:
          path: |
            ~/.opam
            _opam
          key: opam-${{ runner.os }}-${{ matrix.ocaml }}-${{ hashFiles('**/*.opam.locked','monorepo.lock') }}
      - name: Install deps (locked)
        run: |
          opam update
          opam install . --deps-only --locked -y
      - name: Cache dune build
        uses: actions/cache@v4
        with:
          path: _build
          key: dune-${{ runner.os }}-${{ matrix.ocaml }}-${{ hashFiles('**/*','!_build/**') }}
          restore-keys: |
            dune-${{ runner.os }}-${{ matrix.ocaml }}-
      - name: Build (release)
        run: dune build --profile release @install
      - name: Run tests
        run: dune runtest --profile test
      - name: Upload artifacts
        uses: actions/upload-artifact@v4
        with:
          name: acme-${{ matrix.os }}-${{ matrix.ocaml }}
          path: _build/install/default/bin/*
