let test_hello () =
  Alcotest.(check string) "greeting" "hello, world" (Acme_core.hello "world")
let () =
  Alcotest.run "acme" [ "core", [ Alcotest.test_case "hello" `Quick test_hello ] ]
Opam (auto-generated or manual): acme.opam. Add:
