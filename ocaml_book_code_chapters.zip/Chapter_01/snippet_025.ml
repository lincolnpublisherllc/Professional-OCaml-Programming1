dune build --profile release --root . \
  --display=short \
  -x BUILD_VERSION=$(git describe --always --dirty)
