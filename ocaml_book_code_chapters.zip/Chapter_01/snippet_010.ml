Enable “OCaml: Suggest ‘open’” and code lenses in VS Code.
