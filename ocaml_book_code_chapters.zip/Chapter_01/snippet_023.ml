Pin the toolchain: compiler version, dune version, and C toolchain in CI images.
Lock opam deps: opam install --locked.
