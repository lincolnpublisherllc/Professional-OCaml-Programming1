Use opam lock to freeze transitive versions.
opam switch create . 5.2.1 -y
opam install . --deps-only -y
opam lock .                      # creates <pkg>.opam.locked (or monorepo.lock)
