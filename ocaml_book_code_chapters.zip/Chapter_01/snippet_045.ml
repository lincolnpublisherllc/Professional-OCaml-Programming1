opam lock . → commit lockfiles.
dune build --profile release @install → verify binaries exist.
