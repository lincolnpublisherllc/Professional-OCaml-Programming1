open Cmdliner
let run who = print_endline (Acme_core.hello who); Ok ()
let who = Arg.(value & opt string "world" & info ["w"; "who"])
let cmd = Cmd.v (Cmd.info "acme-cli") Term.(ret (const run $ who))
let () = exit (Cmd.eval cmd)
Tests test/dune
(test
