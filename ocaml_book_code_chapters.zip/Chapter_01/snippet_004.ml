opam switch create . 5.2.1 -y
eval "$(opam env)"
This creates a local switch tied to the repo path. Check in an .ocamlformat, dune-project, and *.opam files.
