Ensure CI uses --locked, caches opam + _build, and uploads artifacts.
