  image: ghcr.io/yourorg/ocaml-ci:5.2.1-ubuntu22
