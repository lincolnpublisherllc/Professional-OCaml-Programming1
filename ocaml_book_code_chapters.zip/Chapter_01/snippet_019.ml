Vendoring vs opam pins vs released packages
