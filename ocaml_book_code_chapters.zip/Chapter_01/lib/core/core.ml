let hello who = Printf.sprintf "hello, %s" who
CLI apps/cli/dune
(executable
