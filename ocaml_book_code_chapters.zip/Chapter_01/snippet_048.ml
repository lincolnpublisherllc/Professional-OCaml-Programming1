“Works on my machine”: You forgot --locked in CI or you’re using a different compiler. Fix by enforcing opam switch create . <ver> and --locked everywhere.
CI cache thrash: Keys are too broad (include _build/**). Narrow keys to lockfile hashes and OS/OCaml version.
Mac/Linux differences: Native libraries missing on one platform. Add depext hints to the .opam file and use opam-depext in CI.
