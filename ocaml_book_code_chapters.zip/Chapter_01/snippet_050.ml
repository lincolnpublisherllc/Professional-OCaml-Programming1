Monorepo cache isolation
Add a second app (apps/svc-api) and a second lib (lib/http). Adjust CI cache keys so a change in lib/http invalidates the _build cache for svc-api but not for cli if cli doesn’t depend on it. (Hint: use dune-cache server or split caches per path graph.)
