opam install ocaml-lsp-server merlin ocamlformat -y
