sudo apt-get update
sudo apt-get install -y build-essential m4 git pkg-config libgmp-dev zstd opam
Initialize opam and a global cache directory:
opam init -y --disable-sandboxing  # enable later inside CI runners
opam switch create 5.2.1 -y         # baseline compiler version
eval "$(opam env)"
Tip: keep a bootstrap script at repo root (e.g., script/bootstrap.sh) that installs system packages, initializes opam, and runs make setup. Treat it as the single source of truth for onboarding.
