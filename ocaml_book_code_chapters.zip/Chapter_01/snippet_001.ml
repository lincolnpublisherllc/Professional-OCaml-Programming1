Builds that match CI bit-for-bit (or very close).
