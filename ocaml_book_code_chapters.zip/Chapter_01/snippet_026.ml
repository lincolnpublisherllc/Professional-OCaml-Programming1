Cache opam switch and _build.
