dune build --profile release @install
# binaries in _build/install/default/bin
