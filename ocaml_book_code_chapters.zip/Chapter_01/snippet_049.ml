Hermetic Linux builds
Build in a pinned container image (ubuntu base + ocaml 5.2.1 + dune 3.11). Push the image to a registry and reference it by digest in CI. Prove that two separate runners produce identical SHA256 for your CLI binary.
