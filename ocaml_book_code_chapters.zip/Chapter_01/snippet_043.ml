Initialize repo, dune-project, lib/, apps/, test/ as above.
