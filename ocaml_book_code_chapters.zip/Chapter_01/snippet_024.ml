let version =
  match Sys.getenv_opt "BUILD_VERSION" with
  | Some v -> v | None -> "dev"
