Scan dependencies regularly (e.g., opam-health-check mirrors, Syft/Grype scanners).
