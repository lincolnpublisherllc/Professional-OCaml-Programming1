Neovim: use mason or nvim-lspconfig for ocamllsp, add merlin path from opam var share.
