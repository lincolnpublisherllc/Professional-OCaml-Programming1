dune fmt --auto-promote
git diff --exit-code
