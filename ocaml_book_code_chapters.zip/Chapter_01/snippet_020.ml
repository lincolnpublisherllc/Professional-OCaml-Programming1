opam pins to specific git SHAs:
opam pin add somelib https://github.com/org/somelib.git#<sha> -y
