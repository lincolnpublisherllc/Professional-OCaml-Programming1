module Trie = struct
  module M = Map.Make(Char)
  type 'a t = Node of 'a option * 'a t M.t  (* value at this node + children *)
