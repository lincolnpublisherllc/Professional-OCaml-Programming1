let run paths ~num_domains =
  let pool = Task.setup_pool ~num_additional_domains:(num_domains-1) () in
  let results =
    Task.parallel_for_reduce ~pool ~start:0 ~finish:(List.length paths - 1)
      ~body:(fun i -> aggregate_chunk (List.nth paths i))
      ~reduce:merge_maps
      M.empty
  in
  Task.teardown_pool pool;
  results
