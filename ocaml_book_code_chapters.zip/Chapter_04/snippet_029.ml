  let pop q =
    let rec loop () =
      let head = Atomic.get q.head in
      let next = Atomic.get head.next in
      if next == (Obj.magic 0) then None
      else if Atomic.compare_and_set q.head head next then Some next.v
      else loop ()
    in loop ()
