module Sym : sig
  type t = string
  val compare : t -> t -> int
end = struct
  type t = string
  let compare = String.compare
