  let insert key v =
    let rec go i (Node (here, kids)) =
      if i = String.length key then Node (Some v, kids)
      else
        let c = key.[i] in
        let child = match M.find_opt c kids with Some t -> t | None -> empty in
        let kid' = go (i+1) child in
        Node (here, M.add c kid' kids)
    in go 0
