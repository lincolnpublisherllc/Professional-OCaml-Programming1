  let empty = Node (None, M.empty)
