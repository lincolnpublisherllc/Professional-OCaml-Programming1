  let is_pow2 n = n land (n-1) = 0
  let create n =
    let n = if is_pow2 n then n else 1 lsl (Sys.int_size - (Sys.int_size - 1 - Z.log2 n)) in
    { buf = Array.make n None; mask = n - 1; w = 0; r = 0 }
