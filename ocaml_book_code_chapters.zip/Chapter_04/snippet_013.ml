  let pop q =
    if q.r = q.w then None
    else
      let idx = q.r land q.mask in
      let v = Array.unsafe_get q.buf idx in
      Array.unsafe_set q.buf idx None;
      q.r <- (q.r + 1) land q.mask;
      v
