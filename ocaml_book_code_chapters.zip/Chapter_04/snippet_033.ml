let aggregate_chunk (path : string) : agg M.t =
  let ic = open_in path in
  let rec loop m =
    match input_line ic with
    | exception End_of_file -> close_in ic; m
    | line ->
      if line = "" then loop m else
      match String.split_on_char ',' line with
      | [sym; qty_s; px_s; _ts_s] ->
        let q = int_of_string qty_s and p = float_of_string px_s in
        let a0 = Option.value ~default:{qty=0; notional=0.0} (M.find_opt sym m) in
        loop (M.add sym (add a0 q p) m)
      | _ -> loop m
  in loop M.empty
