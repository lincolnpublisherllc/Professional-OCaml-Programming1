                +---------------------+
   files  ----> |   Work Queue (Q)    | <----- producer (scans directory)
                +---------------------+
                    |       |     |
                    v       v     v
               +--------+--------+--------+
               | worker | worker | worker |  (Domainslib parallel section)
               +--------+--------+--------+
                  | Map      | Map     | Map  (persistent per chunk)
                  +---- merge (deterministic in one domain) -----+
                                      |
                                      v
                              Global persistent Map
                                      |
                                      v
                                CSV (sorted)
