  let topo_order (g : t) : (string list, string) result =
    let preds = ref g in
    let zero =
      M.fold (fun n ps acc -> if S.is_empty ps then n::acc else acc) !preds []
    in
    let rec loop order queue =
      match queue with
      | [] -> if M.is_empty !preds then Ok (List.rev order)
              else Error "cycle"
      | n::qs ->
        preds := M.remove n !preds;
        let preds' =
          M.map (fun ps -> S.remove n ps) !preds in
        preds := preds';
        let newly_zero =
          M.fold (fun m ps acc -> if S.is_empty ps then m::acc else acc) !preds []
        in
        loop (n::order) (newly_zero @ qs)
    in
    loop [] zero
