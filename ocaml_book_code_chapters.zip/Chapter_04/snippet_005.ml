let rollup (rows : (K.t * float) list) : float Sym.Map.t =
  List.fold_left
    (fun acc (k, v) ->
      let open Sym in
      let sum = Option.value ~default:0.0 (Map.find_opt k.sym acc) in
      Map.add k.sym (sum +. v) acc)
    Sym.(Map.empty (module struct type t = string let compare = String.compare end))  (* or your module *)
    rows
