  let union uf a b =
    let ra, rb = find uf a, find uf b in
    if ra = rb then () else
    if uf.rank.(ra) < uf.rank.(rb) then uf.parent.(ra) <- rb
    else if uf.rank.(ra) > uf.rank.(rb) then uf.parent.(rb) <- ra
    else (uf.parent.(rb) <- ra; uf.rank.(ra) <- uf.rank.(ra) + 1)
