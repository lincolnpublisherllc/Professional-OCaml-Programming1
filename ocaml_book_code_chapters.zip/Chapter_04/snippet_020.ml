module Heap = struct
  type 'a t = { a : 'a array; cmp : 'a -> 'a -> int; mutable n : int }
  (* Implement push/pop with sift-up/down; or use a library. *)
