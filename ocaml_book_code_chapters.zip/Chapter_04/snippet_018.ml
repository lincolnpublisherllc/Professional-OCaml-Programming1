  let rec find uf x =
    let p = uf.parent.(x) in
    if p = x then x
    else let r = find uf p in uf.parent.(x) <- r; r
