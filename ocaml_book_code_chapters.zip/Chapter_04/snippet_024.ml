let k_way_merge (files : string list) (out : out_channel) =
  let open Heap in
  let cmp (k1,_) (k2,_) = K.compare k1 k2 in
  let h = create ~capacity:(List.length files) ~cmp in
  let cursors =
    List.filter_map (fun f ->
      let ic = open_in_bin f in
      match read_row ic with
      | None -> close_in ic; None
      | Some kv -> push h kv; Some { ic; current = Some kv })
    files
  in
  (* drain heap, refill from the cursor we popped from *)
  (* combine equal keys during merge to keep outputs small and deterministic *)
  ()
