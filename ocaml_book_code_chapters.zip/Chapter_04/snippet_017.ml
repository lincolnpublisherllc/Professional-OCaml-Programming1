module Uf = struct
  type t = { parent: int array; rank: int array }
  let create n = { parent = Array.init n Fun.id; rank = Array.make n 0 }
