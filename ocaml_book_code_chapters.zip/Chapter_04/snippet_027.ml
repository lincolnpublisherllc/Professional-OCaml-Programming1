  let create () =
    let dummy = { v = Obj.magic 0; next = Atomic.make (Obj.magic 0) } in
    { head = Atomic.make dummy; tail = Atomic.make dummy }
