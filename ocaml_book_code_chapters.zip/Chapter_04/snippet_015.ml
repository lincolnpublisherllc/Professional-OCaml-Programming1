module G = struct
  module S = Set.Make(String)
  module M = Map.Make(String)
  type t = S.t M.t    (* node -> predecessors *)
