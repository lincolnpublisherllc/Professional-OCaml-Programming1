module Time = struct
  type t = int  (* epoch seconds *)
  let compare = Int.compare
