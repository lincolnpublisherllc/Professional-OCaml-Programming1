let read_row ic : (K.t * float) option = (* parse one row; None on EOF *)
