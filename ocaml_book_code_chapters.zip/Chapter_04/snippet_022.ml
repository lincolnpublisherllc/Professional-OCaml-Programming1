type cursor = { ic : in_channel; mutable current : (K.t * float) option }
