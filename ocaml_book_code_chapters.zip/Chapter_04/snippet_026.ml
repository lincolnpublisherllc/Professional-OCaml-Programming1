module Mpsc : sig
  type 'a t
  val create : unit -> 'a t
  val push : 'a t -> 'a -> unit
  val pop  : 'a t -> 'a option
end = struct
  type 'a node = { v: 'a; next: 'a node Atomic.t }
  type 'a t = { head: 'a node Atomic.t; tail: 'a node Atomic.t }
