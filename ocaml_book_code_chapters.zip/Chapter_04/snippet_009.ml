  let longest_prefix key =
    let rec go i best (Node (here, kids)) =
      let best' = match here with Some v -> Some (i, v) | None -> best in
      if i = String.length key then best'
      else
        match M.find_opt key.[i] kids with
        | None -> best'
        | Some t -> go (i+1) best' t
    in fun t -> go 0 None t
