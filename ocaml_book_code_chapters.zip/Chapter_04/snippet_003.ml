Compose comparators lexicographically for multi-field keys. Avoid encoding tuples into strings; let the type system help you.
module K = struct
  type t = { sym: Sym.t; ts: Time.t }
  let compare a b =
    let c = Sym.compare a.sym b.sym in
    if c <> 0 then c else Time.compare a.ts b.ts
