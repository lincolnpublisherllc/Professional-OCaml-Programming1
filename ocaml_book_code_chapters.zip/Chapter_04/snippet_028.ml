  let push q x =
    let n = { v = x; next = Atomic.make (Obj.magic 0) } in
    let rec loop () =
      let tail = Atomic.get q.tail in
      if Atomic.compare_and_set tail.next (Obj.magic 0) n
      then ignore (Atomic.compare_and_set q.tail tail n)
      else loop ()
    in loop ()
