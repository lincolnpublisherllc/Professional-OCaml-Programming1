(* Sketch: adj : (node -> (neighbor * weight) list). Dijkstra uses Heap keyed by distance. *)
