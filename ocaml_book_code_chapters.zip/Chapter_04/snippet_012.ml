  let push q x =
    let next = (q.w + 1) land q.mask in
    if next = q.r then false
    else (Array.unsafe_set q.buf (q.w land q.mask) (Some x); q.w <- next; true)
