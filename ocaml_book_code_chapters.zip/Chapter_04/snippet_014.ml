let merge_htbl_into_map (h : (Sym.t, float) Hashtbl.t) (m : float Sym.Map.t) =
  Hashtbl.fold (fun k v acc ->
    let v' = match Sym.Map.find_opt k acc with Some x -> x +. v | None -> v in
    Sym.Map.add k v' acc) h m
