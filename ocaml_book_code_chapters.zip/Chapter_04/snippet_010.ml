module Spsc_ring : sig
  type 'a t
  val create : int -> 'a t
  val push : 'a t -> 'a -> bool   (* false if full *)
  val pop  : 'a t -> 'a option    (* None if empty *)
end = struct
  type 'a t = {
    buf : 'a option array; (* use [Obj.magic] + separate occupancy if you want no options *)
    mask: int;             (* size power-of-two; mask = size-1 *)
    mutable w : int;       (* write index *)
    mutable r : int;       (* read index *)
  }
