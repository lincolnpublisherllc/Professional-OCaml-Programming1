let merge_maps (ms : agg M.t list) : agg M.t =
  List.fold_left
    (fun acc m ->
      M.merge (fun _ a b ->
        match a, b with
        | None, None -> None
        | Some x, None | None, Some x -> Some x
        | Some x, Some y -> Some { qty = x.qty + y.qty; notional = x.notional +. y.notional })
        acc m)
    M.empty ms
