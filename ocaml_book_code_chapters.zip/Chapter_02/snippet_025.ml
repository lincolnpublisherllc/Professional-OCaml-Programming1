let fetch_many ~net urls =
  Switch.run @@ fun sw ->
    let results = Array.make (List.length urls) "" in
    List.iteri (fun i url ->
      Fiber.fork ~sw (fun () ->
        let body = Net.get net (Uri.of_string url) in
        results.(i) <- Cstruct.to_string body))
      urls;
    Array.to_list results
