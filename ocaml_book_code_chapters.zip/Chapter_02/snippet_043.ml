type mode = Fast | Safe [@@deriving enum, show]
