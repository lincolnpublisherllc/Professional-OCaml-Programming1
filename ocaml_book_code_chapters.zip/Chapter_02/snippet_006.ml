let run (module L : LOG) =
  L.info "started"; (* ... *)
