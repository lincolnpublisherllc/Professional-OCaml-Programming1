let gen_cli_for_record ~loc ~path (ld : label_declaration) =
  let open Ast_builder.Default in
  (* inspect field name/type, build Cmdliner Arg.t *)
  (* return structure item fragments *)
  [%stri let _ = ()]  (* placeholder; see project section for full code *)
