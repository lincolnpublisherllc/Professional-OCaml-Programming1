(* In the generator, given type name "cfg" produce module Cfg_cli & Cfg_json *)
