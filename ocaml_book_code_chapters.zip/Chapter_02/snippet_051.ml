let generate modules_for (td: type_declaration) =
  match td.ptype_kind with
  | Ptype_record fields ->
      let terms = List.map (field_to_cmdliner ~loc:td.ptype_loc) fields in
      (* Build a term that constructs the record from field terms *)
      let ctor =
        (* Cmdliner.Term.const (fun port host mode -> {port;host;mode}) $ arg_port $ arg_host $ arg_mode *)
        [%stri let term = Cmdliner.Term.const (fun _ -> assert false) ]
      in
      terms @ [ctor]
  | _ -> Location.raise_errorf ~loc:td.ptype_loc "[@@deriving app] on records only"
