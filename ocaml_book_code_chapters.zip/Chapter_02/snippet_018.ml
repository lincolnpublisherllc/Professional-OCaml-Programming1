let handle : type a. a route -> a = function
  | Health      -> ()
  | Metrics     -> [ "requests", 1234; "errors", 0 ]
  | User { id } -> Printf.sprintf "user-%d" id
Each route’s result type is encoded in the constructor.
