Prefer functors for hot paths, first-class modules for runtime selection. Don’t mix models in a single module.
