Emit a Cmdliner Arg.t with docs and defaults.
