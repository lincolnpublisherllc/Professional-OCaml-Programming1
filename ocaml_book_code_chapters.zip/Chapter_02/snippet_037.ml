type 'a decoder = string -> int -> ('a * int) option
