Objective: Build a PPX deriver [@@deriving app] that, for a record type, generates:
A Cmdliner term to parse CLI flags into the record.
