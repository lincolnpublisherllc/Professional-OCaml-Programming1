type _ route =
  | Health  : unit route
  | Metrics : (string * int) list route
  | User    : { id:int } -> string route
