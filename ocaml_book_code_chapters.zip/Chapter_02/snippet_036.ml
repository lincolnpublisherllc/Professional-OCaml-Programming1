Run dune runtest; failures show diffs of generated code.
