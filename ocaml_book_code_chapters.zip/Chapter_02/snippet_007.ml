module Stdout : LOG = struct let info s = Printf.printf "[I] %s\n" s end
module Null   : LOG = struct let info _ = () end
