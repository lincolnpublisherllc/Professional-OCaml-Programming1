let () =
  let logging =
    match Sys.getenv_opt "QUIET" with Some "1" -> (module Null  : LOG)
    | _ -> (module Stdout : LOG)
  in
  run logging
