module type TOKEN = sig
  type t
  val issue   : user:string -> t
  val is_valid: t -> bool
