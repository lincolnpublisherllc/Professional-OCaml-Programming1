let deriver =
  Deriving.add "cli"
    ~str_type_decl:(Deriving.Generator.make_noarg
      (fun ~loc ~path (_recflag, tds) ->
         List.concat_map (fun td ->
           match td.ptype_kind with
           | Ptype_record fields -> List.map (gen_cli_for_record ~loc ~path) fields
           | _ -> Location.raise_errorf ~loc "cli: record types only")
           tds))
