let () = Driver.register_transformation ~rules:[] "ppx_cli"
You’ll expand this in the chapter project to emit a full Cmdliner parser and a JSON config loader.
