type _ expr =
  | Lit  : float -> float expr
  | Add  : float expr * float expr -> float expr
  | If   : bool expr * 'a expr * 'a expr -> 'a expr
  | Eq   : float expr * float expr -> bool expr
