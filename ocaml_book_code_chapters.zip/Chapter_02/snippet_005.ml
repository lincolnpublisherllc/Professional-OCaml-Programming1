module type LOG = sig val info : string -> unit end
