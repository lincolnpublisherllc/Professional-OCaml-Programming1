Use one concurrency model per module; adapter at boundaries if you must mix.
