type uninit
type ready
