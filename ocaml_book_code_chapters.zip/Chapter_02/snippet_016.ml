let query : ready db -> string -> string = fun (Live {dsn; _}) sql ->
  (* ... use dsn ... *) sql
The type system forbids calling query before connect.
