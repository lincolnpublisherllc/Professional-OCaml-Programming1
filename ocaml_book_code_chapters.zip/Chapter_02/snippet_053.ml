Version the deriver: [@@deriving app_v1] to allow future changes.
