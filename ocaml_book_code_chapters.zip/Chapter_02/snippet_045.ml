let main (c: cfg) = Printf.printf "Serving %s:%d in %s\n" c.host c.port (show_mode c.mode)
let () = Cfg_cli.run ~main
