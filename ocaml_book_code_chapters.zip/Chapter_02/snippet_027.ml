let with_timeout clock secs f =
  Switch.run @@ fun sw ->
    let timed_out = Atomic.make false in
    Fiber.fork ~sw (fun () -> Time.sleep clock secs; Atomic.set timed_out true; Switch.fail sw Exit);
    try Ok (f ()) with Exit when Atomic.get timed_out -> Error `Timeout
