(* token.ml *)
module Make (C: CLOCK) (R: RNG) : TOKEN = struct
  type t = { user: string; issued_at: float; entropy: float }
  let issue ~user = { user; issued_at = C.now_s (); entropy = R.float () }
  let is_valid t = C.now_s () -. t.issued_at < 3600. && t.entropy >= 0.0
