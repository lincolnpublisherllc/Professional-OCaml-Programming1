2.3.2 Polymorphic variants (open, structural)
let as_html = function
  | `Txt s -> "<p>" ^ s ^ "</p>"
  | `Img src -> "<img src=\"" ^ src ^ "\">"
Pros: ad-hoc extension, no need for a common type declaration.
Cons: weaker global exhaustiveness; can drift without careful curation.
Use for small open sets (renderers, tags) and when interop with external libs favors them.
2.3.3 Extensible variants (open sum you can grow)
Define a shared open type for plugins:
type effect = ..
type effect += Log of string | Sleep of float
