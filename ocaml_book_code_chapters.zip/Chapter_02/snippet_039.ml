let list_d (d : 'a decoder) : 'a list decoder =
  fun s i -> (* parse length, then loop calling d; no allocations beyond output *)
    (* ... *)
    None
