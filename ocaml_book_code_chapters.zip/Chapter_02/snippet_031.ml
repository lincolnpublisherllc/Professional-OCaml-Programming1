Design a deriver [@@deriving cli] that, for a record type, generates a cmdliner term.
(* ppx_cli.ml *)
open Ppxlib
