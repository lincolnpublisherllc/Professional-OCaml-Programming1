Determine base type (int, string, custom with [[@@deriving enum]] or a provided codec).
