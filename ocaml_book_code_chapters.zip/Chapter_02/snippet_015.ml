let connect : uninit db -> ready db = function
  | Conn c -> Live { pid = Unix.getpid (); dsn = c.dsn }
