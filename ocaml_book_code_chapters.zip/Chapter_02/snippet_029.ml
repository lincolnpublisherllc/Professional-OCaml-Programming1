PPX rewriters let you extend syntax and generate code. Treat them as compiler plugins with strict tests.
