Extensible event bus
Define event = .. with base constructors Log of string and Metric of string * int. In a separate module, extend with Alert of string. Write a dispatcher that processes all known events and logs a warning for unknowns.
Eio cancellation lab
Create two fibers: one prints a heartbeat; the other fails after 500 ms. Show that the heartbeat stops due to cancellation and resources are cleaned up.
PPX incremental
Implement a subset of the project: derive Cmdliner terms for int and string fields only. Add attributes for default/env. Write two golden tests and a runtime test.
Zero-cost codec
Build a staged CSV decoder that returns a function specialized to a given schema: val make_decoder : schema -> (string -> 'a option). Show reduced allocations vs a generic decoder.
