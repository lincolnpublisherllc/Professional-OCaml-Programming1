let int_d : int decoder = fun s i ->
  match int_of_string_opt s with Some n -> Some (n, i+1) | None -> None
