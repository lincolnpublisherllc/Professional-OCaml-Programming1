let () = Eio_main.run @@ fun env ->
  fetch_many ~net:env#net ["https://example.com"; "https://ocaml.org"]
  |> List.iter print_endline
