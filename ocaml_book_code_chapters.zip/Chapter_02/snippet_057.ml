The module system is your macro for architecture: functors for speed and static safety, first-class modules for runtime composition.
