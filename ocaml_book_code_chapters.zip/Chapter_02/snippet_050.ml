(* For brevity, a simplified field mapper *)
let field_to_cmdliner ~loc (ld: label_declaration) =
  let open Ast_builder.Default in
  let name = ld.pld_name.txt in
  let ty = ld.pld_type in
  (* map core_type -> cmdliner converter and env reader *)
  let term_id = "arg_" ^ name in
  [%stri
    let [%p pvar term_id] =
      (* Cmdliner.Arg.(value & opt int 8080 & info ["port"] ~doc:"...") etc. *)
      (* Fill from attributes and type inspection *)
      failwith "generated"
  ]
