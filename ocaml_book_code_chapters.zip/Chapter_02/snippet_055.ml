Compile-time vs runtime injection
Take a request logger. Implement it twice: (a) functor over a CLOCK and WRITER; (b) runtime-selectable (module LOG). Benchmark the hot path and document the trade-offs.
