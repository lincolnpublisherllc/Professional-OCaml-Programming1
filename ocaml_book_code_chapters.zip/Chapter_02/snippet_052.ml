Golden rewrite tests: input type → generated code.
