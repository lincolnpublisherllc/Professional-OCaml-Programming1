(* sigs.mli *)
module type CLOCK = sig val now_s : unit -> float end
module type RNG   = sig val float : unit -> float end
