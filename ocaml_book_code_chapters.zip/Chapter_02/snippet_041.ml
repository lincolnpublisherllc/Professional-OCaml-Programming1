module Make_runner (D: DB) = struct
  let run_queries qs =
    let conn = D.connect () in
    List.iter (D.run conn) qs
