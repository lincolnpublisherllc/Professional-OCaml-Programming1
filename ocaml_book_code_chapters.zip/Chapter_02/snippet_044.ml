type cfg = {
  port : int [@cli.default 8080] [@cli.env "APP_PORT"];
  host : string [@cli.default "0.0.0.0"];
  mode : mode [@cli.default Safe];
} [@@deriving app]  (* generates Cfg_cli.term : cfg Cmdliner.Term.t, Cfg_json.load : string -> (cfg, _) result *)
