let rec eval : type a. a expr -> a = function
  | Lit x -> x
  | Add (a,b) -> eval a +. eval b
  | Eq (a,b) -> eval a = eval b
  | If (c,t,e) -> if eval c then eval t else eval e
