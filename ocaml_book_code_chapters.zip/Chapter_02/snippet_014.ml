type 'state db =
  | Conn : { dsn: string } -> uninit db
  | Live : { pid: int; dsn: string } -> ready db
