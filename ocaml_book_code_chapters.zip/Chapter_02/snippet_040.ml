module type DB = sig type conn val connect : unit -> conn val run : conn -> string -> unit end
