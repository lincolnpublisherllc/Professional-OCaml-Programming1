First-class module: runtime selection, ideal for tests/plugins.
