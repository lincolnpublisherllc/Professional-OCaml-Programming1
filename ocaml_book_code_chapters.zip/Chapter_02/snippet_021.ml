type color = Red | Green | Blue
