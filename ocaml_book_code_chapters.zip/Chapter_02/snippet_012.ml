2.2 GADTs and type-level design for safe APIs
