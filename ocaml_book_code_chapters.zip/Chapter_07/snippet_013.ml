  001_init.sql
  002_add_prices.sql
let run_migrations conn =
  (* load files in order, exec in a transaction; store applied versions in a table *)
  ()
