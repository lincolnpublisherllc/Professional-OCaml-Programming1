let with_cache cache key ~ttl ~compute =
  cache#get key >>= function
  | Some v -> Lwt.return v
  | None ->
    compute () >>= fun v ->
    cache#setx ~key ~value:v ~ttl >|= fun () -> v
