(* keyset paging by (date, sym) *)
(* WHERE (date, sym) > ($date, $sym) ORDER BY date, sym LIMIT $n *)
