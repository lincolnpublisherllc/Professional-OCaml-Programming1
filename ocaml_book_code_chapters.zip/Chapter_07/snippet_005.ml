let with_conn { pool } f =
  Caqti_lwt.Pool.use pool (fun conn ->
    f conn >|= function
    | Ok x -> Ok x
    | Error (`Decode _ as e) -> Error e
    | Error (`Sql msg) -> Error (`Sql msg))
