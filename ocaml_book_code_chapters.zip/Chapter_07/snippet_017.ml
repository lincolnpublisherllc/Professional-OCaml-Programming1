let rec consume forever handler =
  match Kafka.poll consumer ~timeout_ms:100 with
  | Some msg ->
      (match handler msg with
       | Ok () -> Kafka.commit consumer msg
       | Error _ -> (* send to DLQ or retry with backoff *));
      consume forever handler
  | None -> consume forever handler
