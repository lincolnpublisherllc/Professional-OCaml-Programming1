(* ports/cache.mli *)
module type S = sig
  type t
  val get  : t -> string -> string option Lwt.t
  val setx : t -> key:string -> value:string -> ttl:int -> unit Lwt.t
  val incr : t -> string -> int Lwt.t
  val eval : t -> script:string -> keys:string list -> argv:string list -> string list Lwt.t
