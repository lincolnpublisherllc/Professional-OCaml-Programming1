module type STORE = sig
  type t
  val add_trade : t -> sym:string -> qty:int -> px:float -> ts:int -> (unit, [> `Sql of string ]) result Lwt.t
  val closes_on : t -> date:int -> ( (string * float) list, [> `Sql of string ]) result Lwt.t
