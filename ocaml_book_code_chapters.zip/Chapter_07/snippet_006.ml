module Q = struct
  open Caqti_type
