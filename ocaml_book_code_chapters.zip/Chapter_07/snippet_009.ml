  let paged_trades =
    (tup2 int int) ->* (tup4 string int float int),
    "SELECT sym, qty, px, ts FROM trades ORDER BY ts ASC LIMIT $2 OFFSET $1"
