Use a builder stage with opam/dune and a small runtime stage.
# Builder
FROM ocaml/opam:ubuntu-22.04 as build
