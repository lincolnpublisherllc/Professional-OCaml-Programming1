let () = Eio_main.run @@ fun env ->
  let store = Store_postgres.connect_exn (Cfg.db_uri ()) in
  let cache = Cache_redis.connect_exn (Cfg.redis_uri ()) in
  let s3    = S3.make (Cfg.s3_creds ()) in
  Http.serve ~env ~routes:[
    post "/trades" (Handlers.ingest ~store ~cache);
    get  "/prices/:date" (Handlers.prices ~store);
    post "/uploads/init" (Handlers.init_upload ~s3);
    get  "/healthz" (Handlers.healthz);
    get  "/readyz"  (Handlers.readyz ~store ~cache ~s3);
  ]
