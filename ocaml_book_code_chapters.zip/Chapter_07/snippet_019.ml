let hmac_sha256 ~key data = (* ... *);;
let sha256_hex s = (* ... *);;
