type err = [ `Conn of string | `Sql of string | `Decode of string ]
type t = { pool : (Caqti_lwt.connection, Caqti_error.t) Caqti_lwt.Pool.t }
