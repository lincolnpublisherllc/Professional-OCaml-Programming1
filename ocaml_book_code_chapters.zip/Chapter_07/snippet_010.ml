let add_trade conn (sym,qty,px,ts) =
  let (ptype, sql) = Q.insert_trade in
  Caqti_lwt.Connection.exec conn (Caqti_request.exec ptype sql) (sym,qty,px,ts)
  >|= Result.map_error (fun e -> `Sql (Caqti_error.show e))
