Objects: presigned URLs; multipart for large uploads; content-type set.
