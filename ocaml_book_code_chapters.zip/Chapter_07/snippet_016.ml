let claim_idempotency cache key payload ttl =
  (* returns true if claimed, false if duplicate *)
  cache#eval
    ~script:"return redis.call('SET', KEYS[1], ARGV[1], 'NX', 'EX', ARGV[2]) and '1' or '0'"
    ~keys:[key] ~argv:[payload; string_of_int ttl]
  >|= function ["1"] -> true | _ -> false
