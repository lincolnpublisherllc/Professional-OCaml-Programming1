  let select_closes_on =
    int ->* (tup2 string float),
    "SELECT sym, close FROM prices WHERE date = $1 ORDER BY sym"
