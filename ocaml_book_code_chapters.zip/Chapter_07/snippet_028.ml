module type OBJECTS = sig
  type t
  val presign_get : t -> key:string -> expires:int -> Uri.t
  val presign_put_multipart : t -> key:string -> part:int -> upload_id:string -> Uri.t
