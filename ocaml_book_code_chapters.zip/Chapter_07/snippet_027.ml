module type CACHE = sig
  type t
  val get_trade_hash : t -> string -> string option Lwt.t
  val claim_idempotency : t -> key:string -> payload:string -> ttl:int -> bool Lwt.t
