Keep part size ≥ 8 MB; parallelize with a bounded Eio pool; retry with backoff.
