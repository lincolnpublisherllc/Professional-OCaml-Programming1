let presign_get ~creds ~bucket ~key ~expires_s =
  let now = (* yyyymmddThhmmssZ *), date = (* yyyymmdd *) in
  let host = Printf.sprintf "%s.s3.%s.amazonaws.com" bucket creds.region in
  let canonical_qs = [
    "X-Amz-Algorithm", "AWS4-HMAC-SHA256";
    "X-Amz-Credential", Printf.sprintf "%s/%s/%s/%s/aws4_request"
      creds.access_key date creds.region creds.service;
    "X-Amz-Date", now;
    "X-Amz-Expires", string_of_int expires_s;
    "X-Amz-SignedHeaders", "host";
  ] |> Uri.encoded_of_query in
  let canonical_req =
    "GET\n/" ^ key ^ "\n" ^ canonical_qs ^ "\nhost:" ^ host ^ "\n\nhost\nUNSIGNED-PAYLOAD"
  in
  let string_to_sign =
    "AWS4-HMAC-SHA256\n" ^ now ^ "\n" ^ date ^ "/" ^ creds.region ^ "/" ^ creds.service ^
    "/aws4_request\n" ^ sha256_hex canonical_req
  in
  let k_date    = hmac_sha256 ~key:("AWS4" ^ creds.secret_key) date in
  let k_region  = hmac_sha256 ~key:k_date creds.region in
  let k_service = hmac_sha256 ~key:k_region creds.service in
  let k_signing = hmac_sha256 ~key:k_service "aws4_request" in
  let sighex = hex (hmac_sha256 ~key:k_signing string_to_sign) in
  Uri.of_string (Printf.sprintf "https://%s/%s?%s&X-Amz-Signature=%s" host key canonical_qs sighex)
