let healthz _ = `Ok "ok"
let readyz store cache s3 =
  match%lwt Store.ping store, Cache.ping cache, S3.ping s3 with
  | Ok (), Ok (), Ok () -> Lwt.return (`Ok "ready")
  | _ -> Lwt.return (`Service_unavailable "not ready")
