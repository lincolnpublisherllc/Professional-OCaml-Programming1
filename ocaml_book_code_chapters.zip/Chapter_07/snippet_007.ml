  let insert_trade =
    (tup4 string int float int) ->. unit,
    "INSERT INTO trades(sym, qty, px, ts) VALUES ($1,$2,$3,$4)"
