let connect (uri : Uri.t) : (t, err) result Lwt.t =
  Caqti_lwt.connect_pool ~max_size:20 uri >|= function
  | Ok pool -> Ok { pool }
  | Error e -> Error (`Conn (Caqti_error.show e))
