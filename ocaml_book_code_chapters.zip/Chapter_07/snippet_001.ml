(* ports/store.mli *)
module type S = sig
  type t
  type err = [ `Conn of string | `Sql of string | `Decode of string ]
  val with_conn : t -> (Caqti_lwt.connection -> ('a, err) result Lwt.t) -> ('a, err) result Lwt.t
