let stream_closes_on conn date k =
  let (rtyp, sql) = Q.select_closes_on in
  let req = Caqti_request.collect Caqti_type.int rtyp sql in
  Caqti_lwt.Connection.fold conn req date () (fun () (sym, px) -> k sym px)
  >|= Result.map_error (fun e -> `Sql (Caqti_error.show e))
