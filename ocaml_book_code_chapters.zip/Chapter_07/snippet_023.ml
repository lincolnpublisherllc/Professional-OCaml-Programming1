RUN opam switch create . 5.2.1 -y && eval $(opam env) \
 && opam install . --deps-only --locked -y \
 && dune build --profile=release @install
