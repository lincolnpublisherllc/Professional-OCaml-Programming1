Avoid long-lived references to large transient buffers (let them go out of scope).
