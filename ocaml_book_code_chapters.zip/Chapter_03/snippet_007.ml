let memcpy =
  foreign "memcpy" (ptr void @-> ptr void @-> size_t @-> returning (ptr void))
