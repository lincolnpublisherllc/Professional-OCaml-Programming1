Symbol table without string copies
Implement an open-addressing hash table keyed by (off,len) slices into the bigarray, with a stable hash for interning only when a symbol is first seen.
