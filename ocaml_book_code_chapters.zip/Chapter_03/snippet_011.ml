let sum_unchecked (a: int array) =
  let n = Array.length a in
  let acc = ref 0 in
  for i = 0 to n - 1 do
    acc := !acc + Array.unsafe_get a i
  done; !acc
