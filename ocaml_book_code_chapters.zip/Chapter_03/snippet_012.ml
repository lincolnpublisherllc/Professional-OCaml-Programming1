Encapsulate in a single module; expose a typed, documented function instead of magic at call sites.
