type agg = { mutable qty: int; mutable notional: float }
