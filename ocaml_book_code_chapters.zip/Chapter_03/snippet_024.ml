type agg = { mutable qty: int; mutable notional: float }
let aggregate_zero_copy path =
  let ba, fd, len = mmopen path in
  let st = SymTbl.create () in
  let tbl : (int, agg) Hashtbl.t = Hashtbl.create 65536 in
  let parse_line acc off ln =
    (* locate commas *)
    let findc c i limit =
      let j = ref i in
      while !j < limit && Array1.unsafe_get ba !j <> c do incr j done; !j in
    let c1 = findc ',' off (off+ln) in
    let c2 = findc ',' (c1+1) (off+ln) in
    let c3 = findc ',' (c2+1) (off+ln) in
    (* sym, qty, px, ts *)
    let sym_id = SymTbl.intern st ba off (c1 - off) in
    let qty    = parse_int ba (c1+1) (c2 - c1 - 1) in
    let px     = parse_float_fast ba (c2+1) (c3 - c2 - 1) in
    let a = match Hashtbl.find_opt tbl sym_id with
      | Some a -> a
      | None -> let a = { qty=0; notional=0.0 } in Hashtbl.add tbl sym_id a; a
    in
    a.qty <- a.qty + qty;
    a.notional <- a.notional +. float_of_int qty *. px;
    acc
  in
  let _n = fold_lines ba len ~init:() ~f:parse_line in
  Unix.close fd; (tbl, st)
