module SymTbl = struct
  type t = { tbl: (int, string) Hashtbl.t; rev: (string, int) Hashtbl.t; mutable next: int }
  let create () = { tbl=Hashtbl.create 65536; rev=Hashtbl.create 65536; next=0 }
  let intern st (ba:buf) off len =
    (* hash on bytes without building a string *)
    let h = ref 0 in
    for k=0 to len-1 do h := (!h * 65599) lxor (Char.code (Array1.unsafe_get ba (off+k))) done;
    (* open addressing via rev: we still need a string key; compromise: build once *)
    (* Option: use bytes → copy once per distinct symbol *)
    let s = Bytes.create len in
    for k=0 to len-1 do Bytes.unsafe_set s k (Array1.unsafe_get ba (off+k)) done;
    let key = Bytes.unsafe_to_string s in
    match Hashtbl.find_opt st.rev key with
    | Some id -> id
    | None ->
        let id = st.next in
        st.next <- id + 1;
        Hashtbl.add st.rev key id; Hashtbl.add st.tbl id key; id
