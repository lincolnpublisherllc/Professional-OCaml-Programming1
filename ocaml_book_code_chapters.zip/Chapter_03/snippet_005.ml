External stubs (external with C files compiled by dune).
