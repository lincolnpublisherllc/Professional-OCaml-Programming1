let parse_float_fast ba off len =
  (* Simple fast path: int or int.frac; no exponent. Extend as needed. *)
  let s = Bytes.create len in   (* optional: avoid if you implement full in-place parse *)
  for k = 0 to len - 1 do Bytes.unsafe_set s k (Array1.unsafe_get ba (off+k)) done;
  float_of_string (Bytes.unsafe_to_string s)
