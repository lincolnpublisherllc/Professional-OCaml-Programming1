open Bigarray
type buf = (char, int8_unsigned_elt, c_layout) Array1.t
