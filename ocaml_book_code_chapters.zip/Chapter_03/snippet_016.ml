let aggregate_baseline file =
  let txt = In_channel.with_open_text file In_channel.input_all in
  let tbl = Hashtbl.create 10_000 in
  txt
  |> String.split_on_char '\n'
  |> List.iter (fun line ->
       if line <> "" then
         let (sym, qty, px) = parse_row line in
         let a = Hashtbl.find_opt tbl sym |> Option.value ~default:{qty=0;notional=0.} in
         a.qty <- a.qty + qty;
         a.notional <- a.notional +. float_of_int qty *. px;
         Hashtbl.replace tbl sym a);
  tbl
