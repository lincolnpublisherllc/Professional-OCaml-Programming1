Compile to a .a/.so and link via dune.
