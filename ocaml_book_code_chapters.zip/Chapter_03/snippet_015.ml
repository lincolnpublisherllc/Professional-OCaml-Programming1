let parse_row s =
  match String.split_on_char ',' s with
  | [sym; qty_s; px_s; _ts_s] ->
      let qty = int_of_string qty_s
      and px  = float_of_string px_s in
      sym, qty, px
  | _ -> failwith "bad row"
