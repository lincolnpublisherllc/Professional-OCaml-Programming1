measure "baseline" (fun () -> aggregate_baseline file)
measure "zero-copy" (fun () -> aggregate_zero_copy file)
