let ba_to_ptr (ba: (char, _, _) Bigarray.Array1.t) =
  bigarray_start array1 ba
