let () =
  let g = Gc.get () in
  Gc.set { g with minor_heap_size = 16 * 1024 * 1024; space_overhead = 120 }
