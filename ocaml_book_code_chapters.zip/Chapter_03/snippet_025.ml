let measure name f =
  Gc.full_major ();
  let s0 = Gc.quick_stat () in
  let t0 = Mtime_clock.now () in
  let r  = f () in
  let dt = Mtime.(Span.to_ms (span t0 (now ()))) in
  let s1 = Gc.quick_stat () in
  Printf.printf "%s: %.1f ms | minor_words=%.0f -> %.0f | major_words=%.0f -> %.0f\n"
    name dt s0.minor_words s1.minor_words s0.major_words s1.major_words;
  r
