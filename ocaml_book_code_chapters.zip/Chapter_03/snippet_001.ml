let dot (a: float array) (b: float array) =
  let n = Array.length a in
  let acc = ref 0.0 in
  for i = 0 to n - 1 do
    acc := !acc +. a.(i) *. b.(i)
  done;
  !acc
