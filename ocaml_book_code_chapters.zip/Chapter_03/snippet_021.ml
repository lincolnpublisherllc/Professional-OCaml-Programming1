let parse_int (ba: buf) off len =
  let neg = ref false in
  let i = ref off in
  if len > 0 && Array1.unsafe_get ba !i = '-' then (neg := true; incr i);
  let v = ref 0 in
  while !i < off + len do
    let c = Char.code (Array1.unsafe_get ba !i) - 48 in
    if c < 0 || c > 9 then raise Exit;
    v := !v * 10 + c; incr i
  done;
  if !neg then - !v else !v
