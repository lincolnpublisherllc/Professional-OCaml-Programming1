let fold_lines (ba: buf) len ~init ~f =
  let rec loop i acc =
    if i >= len then acc
    else
      (* find next '\n' or len *)
      let j = ref i in
      while !j < len && Array1.unsafe_get ba !j <> '\n' do incr j done;
      let acc' = if !j > i then f acc i (!j - i) else acc in
      loop (!j + 1) acc'
  in loop 0 init
