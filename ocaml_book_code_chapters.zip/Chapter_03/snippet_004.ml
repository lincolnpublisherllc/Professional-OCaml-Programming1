let blit_string_to_ba s ba =
  for i = 0 to String.length s - 1 do
    Array1.unsafe_set ba i s.[i]
  done
