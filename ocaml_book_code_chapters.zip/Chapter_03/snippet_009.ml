let rec read_full fd (ba: buf) off len =
  if len = 0 then 0 else
  let written =
    Unix.read fd (Array1.start ba |> Ctypes.to_voidp |> Ctypes.from_voidp char)
               off len
  in
  if written = 0 then 0 else written + read_full fd ba (off + written) (len - written)
