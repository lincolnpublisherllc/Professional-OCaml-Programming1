let mmopen path : buf * File_descr.t * int =
  let fd = Unix.openfile path [O_RDONLY] 0 in
  let file_len = (Unix.fstat fd).st_size in
  let ba =
    Unix.map_file fd char c_layout false [| file_len |]
    |> Obj.magic (* Array1 of length file_len *) in
  (ba, fd, file_len)
