let make_buf n : buf = Array1.create char c_layout n
