(* dune: (libraries ctypes.foreign) *)
open Ctypes
open Foreign
