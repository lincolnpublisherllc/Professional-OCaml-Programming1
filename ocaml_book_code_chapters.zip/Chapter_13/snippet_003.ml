open QCheck
let prop_encode_decode =
  Test.make ~count:500 ~name:"json roundtrip"
    (list small_int) (fun xs ->
      let j = Json.encode_ints xs in
      match Json.decode_ints j with Ok ys -> xs = ys | _ -> false)
