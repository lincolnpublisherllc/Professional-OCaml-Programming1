Lockfiles (opam lock), pinned toolchain (ocaml-base-compiler version).
