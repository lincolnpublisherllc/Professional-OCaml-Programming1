Link examples directly from .mli ((** … *)).
