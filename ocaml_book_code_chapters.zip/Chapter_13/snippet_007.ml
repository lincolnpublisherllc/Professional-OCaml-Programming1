Cache opam switch per ocaml-compiler + opam.locked.
Cache dune _build keyed by hash of source + dune version.
