let%test "sum_nonneg" =
  Sum.sum [0;1;2] = 3
