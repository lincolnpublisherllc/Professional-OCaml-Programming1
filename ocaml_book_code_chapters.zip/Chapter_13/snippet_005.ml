Hermetic containers for CI (fixed base image, cached opam switch).
