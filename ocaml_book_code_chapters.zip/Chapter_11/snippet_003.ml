Expose pure functions (val conv2d : mat -> mat -> mat) so you can test and swap implementations.
