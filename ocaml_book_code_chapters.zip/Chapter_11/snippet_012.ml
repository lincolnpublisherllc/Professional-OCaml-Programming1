module Engine = struct
  (* z-score over trailing window; SoA for speed *)
  let trailing_z ~window (series : (int * float) array) : (int * float) array =
    (* compute rolling mean/std; output aligned by date *)
    series (* placeholder: implement in a single pass *)
