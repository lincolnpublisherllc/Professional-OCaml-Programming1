let registry : (string, (module FEED_FIRST_CLASS)) Hashtbl.t = Hashtbl.create 8
