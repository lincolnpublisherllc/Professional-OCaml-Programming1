module type FEED_FIRST_CLASS = sig
  val with_prices :
    sym:string -> start:int -> stop:int -> ( (int * float) list, [> `Not_found | `Io of string ]) result
