Parallel where pure: Domainslib for numeric kernels; Eio for streaming I/O; actors for coordination.
