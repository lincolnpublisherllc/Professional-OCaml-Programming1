type vec2 = { mutable x: float; mutable y: float }
type world = { pos: (id, vec2) Hashtbl.t; vel: (id, vec2) Hashtbl.t }
