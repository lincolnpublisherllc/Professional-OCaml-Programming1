  let pnl_of_weights (weights : weight array) (returns : (int * float) array) : pnl array =
    [||]  (* align by (date,sym); contrib = w * ret *)
