type scenario = { shock_curve: float array; shock_vol: float array }
type pricer = scenario -> float
let portfolio_value pool pricers sc =
  Domainslib.Task.parallel_for_reduce ~pool ~start:0 ~finish:(Array.length pricers - 1)
    ~body:(fun i -> pricers.(i) sc) ~reduce:( +. ) 0.0
