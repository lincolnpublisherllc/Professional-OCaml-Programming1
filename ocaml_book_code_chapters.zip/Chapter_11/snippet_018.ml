Eio service that:
