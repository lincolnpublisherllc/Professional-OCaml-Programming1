type bar = { date:int; sym:string; px:float }
type signal = { date:int; sym:string; score:float }
type weight = { date:int; sym:string; w:float }
type pnl = { date:int; sym:string; ret:float; contrib:float }
