Don’t couple your logic to a file format; ports/adapters let you change formats without touching the engine.
