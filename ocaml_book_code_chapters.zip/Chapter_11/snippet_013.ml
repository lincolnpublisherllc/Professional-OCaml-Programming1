  let rank_to_weights ~top ~bottom (scores : signal array) : weight array =
    (* long top, short bottom, dollar-neutral *)
    [||]  (* rank per date; assign +-1/N *)
