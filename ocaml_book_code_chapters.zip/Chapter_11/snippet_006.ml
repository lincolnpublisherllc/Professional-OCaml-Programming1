type id = int
module Pos  = Hashtbl.Make (struct type t = id let equal = Int.equal let hash = Hashtbl.hash end)
