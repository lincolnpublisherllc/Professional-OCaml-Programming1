module Mat = struct
  type t = (float, Bigarray.float64_elt, Bigarray.c_layout) Bigarray.Array2.t
  let create m n = Bigarray.Array2.create Bigarray.float64 Bigarray.c_layout m n
