Structure concurrency: Domainslib for CPU kernels, Eio for streaming I/O, actors for coordination.
