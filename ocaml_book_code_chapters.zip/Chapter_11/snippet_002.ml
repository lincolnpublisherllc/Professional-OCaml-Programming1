open Lacaml.D
let gemm_example a b =
  (* c := a * b, where a:(m×k), b:(k×n) *)
  let m, k = Mat.dim1 a, Mat.dim2 a in
  let _k', n = Mat.dim1 b, Mat.dim2 b in
  let c = Mat.create m n in
  gemm ~transa:`N ~transb:`N 1.0 a b 0.0 c; c
