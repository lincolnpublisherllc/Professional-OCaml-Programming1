type 'a col = { data : 'a Bigarray.Array1.t; mutable len : int }
type t = {
  sym   : (char, Bigarray.int8_unsigned_elt, Bigarray.c_layout) Bigarray.Array2.t; (* 8-byte codes *)
  qty   : (int32, Bigarray.int32_elt, Bigarray.c_layout) Bigarray.Array1.t;
  px    : (float, Bigarray.float64_elt, Bigarray.c_layout) Bigarray.Array1.t;
  ts    : (int64, Bigarray.int64_elt, Bigarray.c_layout) Bigarray.Array1.t;
