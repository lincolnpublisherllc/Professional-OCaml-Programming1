module Make_backtest (F: FEED) = struct
  let run feed ~universe ~start ~stop =
    (* fetch prices per sym via F, compute signals/weights/pnl, reduce to report *)
    ()
