module type FEED = sig
  type t
  val with_prices :
    t -> sym:string -> start:int -> stop:int ->
    ((int * float) list, [> `Not_found | `Io of string ]) result
