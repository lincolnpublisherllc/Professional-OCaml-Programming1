                └────────→ Failed → (retry → Ready | DLQ)
