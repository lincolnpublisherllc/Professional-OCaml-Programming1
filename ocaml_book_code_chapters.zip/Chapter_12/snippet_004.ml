  let next_run now t =
    match t.backoff, t.attempt with
    | `None, _ -> t.not_before
    | `Exponential { base_ms; max_ms }, k ->
        Int.min (t.not_before + (base_ms lsl Int.min 20 k)) (now + max_ms)
