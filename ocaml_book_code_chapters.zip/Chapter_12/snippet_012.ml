module type STORE = sig
  type t
  type err = [ `Sql of string ]
  val enqueue      : t -> Task.t -> (unit, err) result
  val pop_leases   : t -> partition:int -> n:int -> owner:string -> ttl_s:int -> (Task.t list, err) result
  val heartbeat    : t -> owner:string -> ids:string list -> (unit, err) result
  val complete     : t -> id:string -> (unit, err) result
  val fail         : t -> id:string -> error:string -> (unit, err) result
  val cancel       : t -> id:string -> (unit, err) result
  val to_dlq       : t -> id:string -> error:string -> (unit, err) result
