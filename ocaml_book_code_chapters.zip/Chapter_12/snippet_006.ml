  id text primary key,
  task jsonb not null,
  error jsonb not null,
  moved_at timestamptz not null default now()
