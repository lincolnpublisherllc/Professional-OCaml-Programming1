module type EXECUTOR = sig
  val run_http : timeout_ms:int -> uri:Uri.t -> body:string -> (int * string, string) result
  val run_shell: timeout_ms:int -> cmd:string -> (int * string, string) result
  val run_fn   : name:string -> payload:string -> (string, string) result
