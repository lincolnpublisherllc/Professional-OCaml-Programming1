  select id
  from tasks
  where status = 'Ready'
    and partition = $1
    and not_before <= now()
  order by not_before asc
  for update skip locked
  limit $2
