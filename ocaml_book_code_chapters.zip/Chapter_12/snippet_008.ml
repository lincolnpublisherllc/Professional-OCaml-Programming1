    lease_owner=$3,
    leased_at=now(),
    lease_ttl_s=$4
