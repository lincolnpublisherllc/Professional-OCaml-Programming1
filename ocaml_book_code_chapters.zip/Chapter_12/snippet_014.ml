module type METRICS = sig
  val inc  : string -> labels:(string * string) list -> unit
  val obs  : string -> float -> labels:(string * string) list -> unit
  val time : string -> labels:(string * string) list -> (unit -> 'a) -> 'a
