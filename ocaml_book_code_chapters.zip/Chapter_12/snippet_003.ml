  type t = {
    id        : id;
    tenant    : string;
    kind      : kind;
    payload   : string;      (* JSON or opaque; validated by plugin *)
    created_at: int;         (* epoch ms *)
    not_before: int;         (* earliest start *)
    deadline  : int option;  (* optional SLA *)
    status    : status;
    attempt   : int;
    max_retry : int;
    backoff   : [ `None | `Exponential of { base_ms:int; max_ms:int } ];
    partition : int;         (* hint for sharding *)
  }
