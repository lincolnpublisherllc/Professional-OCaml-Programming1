Adapters: Eio HTTP server, Caqti/Postgres store, Redis rate limiter (optional), Prometheus exporter.
