module Task = struct
  type id = string
  type kind = Http of Uri.t | Shell of string | Fn of string  (* plugin key *)
  type status = Ready | Leased | Running | Succeeded | Failed | Canceled | Dead_letter
