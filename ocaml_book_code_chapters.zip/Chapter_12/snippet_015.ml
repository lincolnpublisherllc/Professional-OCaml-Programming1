let run_worker ~store ~exec ~metrics ~partition ~owner ~concurrency ~lease_ttl_s =
  Eio.Switch.run @@ fun sw ->
    let sem = Eio.Semaphore.make concurrency in
    let rec loop () =
      let leases = Store.pop_leases store ~partition ~n:concurrency ~owner ~ttl_s:lease_ttl_s |> ok_exn in
      if leases = [] then (Eio.Time.sleep (Eio.Stdenv.clock env) 0.05; loop ())
      else (
        List.iter (fun t ->
          Eio.Semaphore.acquire sem;
          Eio.Fiber.fork ~sw (fun () ->
            Fun.protect ~finally:(fun () -> Eio.Semaphore.release sem) @@ fun () ->
              let start = now_ms () in
              let result =
                match t.kind with
                | Http uri -> Executor.run_http ~timeout_ms: (deadline_budget t) ~uri ~body:t.payload
                | Shell c  -> Executor.run_shell ~timeout_ms:(deadline_budget t) ~cmd:c
                | Fn name  -> Executor.run_fn ~name ~payload:t.payload
              in
              let ms = float_of_int (now_ms () - start) in
              (match result with
               | Ok _ -> ignore (Store.complete store ~id:t.id); metrics.obs "task_ms" ms ~labels:["tenant",t.tenant;"kind", kind_tag t]
               | Error e ->
                   (* decide retry vs dlq; call Store.fail or to_dlq *)
                   ()); ()))
          leases;
        loop ())
    in loop ()
