12.6.1 Worker loop (Eio + bounded concurrency)
