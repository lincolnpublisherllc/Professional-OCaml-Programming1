API (Eio):
