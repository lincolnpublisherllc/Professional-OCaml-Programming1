  id            text primary key,
  tenant        text not null,
  cron          text not null,      -- or ISO8601 repeat
  task_kind     text not null,
  payload       jsonb not null,
  next_fire     timestamptz not null,
  jitter_ms     int not null default 0,
  enabled       boolean not null default true
