Interoperability: add a test that calls a small Lwt client from an Eio service through a single adapter point.
