6.2 Effects runtimes (Eio): switches, cancellation, back-pressure
