Structured concurrency (Eio) gives you lifetimes and cancellation you can reason about.
