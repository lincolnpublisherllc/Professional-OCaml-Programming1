Avoid mixed-model tangles by isolating boundaries and choosing one model per module.
