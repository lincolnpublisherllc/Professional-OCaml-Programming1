Use Eio for I/O; wrap edges with timeouts and bounded concurrency.
