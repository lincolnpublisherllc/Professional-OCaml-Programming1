let accum = Array.make n_domains 0.0 in
(* each domain writes accum.(id) inside the loop *)
