let with_pool ~connections make_conn f =
  let pool = Lwt_pool.create connections make_conn in
  fun x -> Lwt_pool.use pool (fun conn -> f conn x)
