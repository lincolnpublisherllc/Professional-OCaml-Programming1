let worker ~pool mailbox =
  let rec loop () =
    match Mb.recv mailbox with
    | Stop -> ()
    | Compute (arr, reply) ->
        let s =
          Domainslib.Task.parallel_for_reduce ~pool
            ~start:0 ~finish:(Array.length arr - 1)
            ~body:(fun i -> float arr.(i))
            ~reduce:( +. ) 0.0
        in
        reply s; loop ()
  in loop ()
