6.9 Chapter project — Supervisor-managed actors with Domainslib + Eio I/O
