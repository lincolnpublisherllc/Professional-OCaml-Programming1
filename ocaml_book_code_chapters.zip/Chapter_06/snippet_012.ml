let with_timeout clock secs f =
  Switch.run @@ fun sw ->
    Fiber.fork ~sw (fun () -> Time.sleep clock secs; Switch.fail sw Exit);
    try Ok (f ()) with Exit -> Error `Timeout
