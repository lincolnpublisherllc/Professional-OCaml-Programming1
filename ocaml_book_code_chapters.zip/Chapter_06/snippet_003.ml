let with_pool n f =
  let pool = Task.setup_pool ~num_additional_domains:(n - 1) () in
  Fun.protect ~finally:(fun () -> Task.teardown_pool pool) (fun () -> f pool)
