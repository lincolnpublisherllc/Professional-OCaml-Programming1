let map_bounded ~sw ~concurrency xs f =
  let sem = Semaphore.make concurrency in
  let results = Array.make (List.length xs) (Error `Init) in
  List.iteri (fun i x ->
    Semaphore.acquire sem;
    Fiber.fork ~sw (fun () ->
      Fun.protect ~finally:(fun () -> Semaphore.release sem) @@ fun () ->
      results.(i) <- f x)) xs;
  Array.to_list results
