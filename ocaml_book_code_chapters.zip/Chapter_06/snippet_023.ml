6.6.1 CPU offload pool for services (Eio + Domainslib)
module Cpu_pool = struct
  type t = { pool : Domainslib.Task.pool }
  let create ~cores = { pool = Domainslib.Task.setup_pool ~num_additional_domains:(cores-1) () }
  let shutdown t = Domainslib.Task.teardown_pool t.pool
  let map_reduce t ~start ~finish ~body ~reduce ~init =
    Domainslib.Task.parallel_for_reduce ~pool:t.pool ~start ~finish ~body ~reduce init
