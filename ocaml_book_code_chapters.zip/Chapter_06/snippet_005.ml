False sharing: don’t let domains write adjacent cache lines (e.g., per-core accumulators in a float array). Use per-task locals and reduce once.
