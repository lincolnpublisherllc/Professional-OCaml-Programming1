type msg =
  | Compute of int array * (float -> unit)  (* CPU job + callback *)
  | Stop
