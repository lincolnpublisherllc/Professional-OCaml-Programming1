type compute = { id: string; payload: int array }
type result  = { id: string; sum: float; ms: int }
