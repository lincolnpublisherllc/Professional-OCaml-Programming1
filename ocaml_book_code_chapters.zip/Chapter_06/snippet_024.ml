(* Eio handler *)
let handle_heavy ~cpu env payload =
  Cpu_pool.map_reduce cpu ~start:0 ~finish:(Array.length payload - 1)
    ~body:(fun i -> float payload.(i)) ~reduce:( +. ) 0.0
