Mailbox — bounded Eio streams.
Actor — type 'msg actor = { mb : 'msg Mailbox.t; run : unit -> unit }.
