module Mb : MAILBOX = struct
  type 'a t = 'a Eio.Stream.t
  let create () = Eio.Stream.create 1024
  let send = Eio.Stream.add
  let recv = Eio.Stream.take
