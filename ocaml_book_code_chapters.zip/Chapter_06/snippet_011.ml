let () = Eio_main.run @@ fun env ->
  fetch_all ~net:env#net ["https://ocaml.org"; "https://example.com"]
  |> List.iter print_endline
