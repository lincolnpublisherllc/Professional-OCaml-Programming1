The router receives jobs over HTTP (Eio), validates them, and enqueues messages.
Workers consume messages, run CPU-bound tasks via Domainslib, and write results to a store (mock or file) with Eio I/O.
