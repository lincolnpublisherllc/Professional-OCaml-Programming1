(* compute local sum inside the task, reduce at the end *)
