let supervisor ~env ~pool =
  Switch.run @@ fun sw ->
    let w_mb = Mb.create () in
    Fiber.fork ~sw (fun () -> worker ~pool w_mb);
    (* router -> worker *)
    let router_mb = Mb.create () in
    Fiber.fork ~sw (fun () ->
      let rec loop () =
        match Mb.recv router_mb with
        | Stop -> Mb.send w_mb Stop
        | Compute (arr, reply) ->
            Mb.send w_mb (Compute (arr, reply)); loop ()
      in loop ());
    (router_mb, w_mb)
