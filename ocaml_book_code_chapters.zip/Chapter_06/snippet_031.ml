type msg =
  | Submit of compute
  | Completed of result
  | Stop
