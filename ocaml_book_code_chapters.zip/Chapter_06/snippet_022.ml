Don’t spawn Lwt promises inside Eio fibers repeatedly; isolate with an adapter module.
