let with_timeout s p =
  Lwt.pick [ (Lwt_unix.sleep s >|= fun () -> Error `Timeout); (p >|= fun v -> Ok v) ]
6.3.3 Interop with Eio
Use eio_lwt bridge when you must call Lwt code from Eio or vice versa.
