let fetch_many_bounded ~net ~concurrency urls =
  Switch.run @@ fun sw ->
    let sem = Semaphore.make concurrency in
    let results = Array.make (List.length urls) (Error `Init) in
    List.iteri (fun i u ->
      Semaphore.acquire sem;
      Fiber.fork ~sw (fun () ->
        Fun.protect ~finally:(fun () -> Semaphore.release sem) @@ fun () ->
        results.(i) <- Ok (Net.get net (Uri.of_string u) |> Cstruct.length))) urls;
    results
