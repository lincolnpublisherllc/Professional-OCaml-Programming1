Worker_actor receives Submit, computes sum via Cpu_pool.map_reduce, writes {id,sum} to a file (Eio Flow) and sends Completed to a results mailbox.
