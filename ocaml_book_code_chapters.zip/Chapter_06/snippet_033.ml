Choose one concurrency model per module.
