  1) opam switch create . 5.1.1
  2) opam install . --deps-only --locked
  3) dune exec ./repro.exe
