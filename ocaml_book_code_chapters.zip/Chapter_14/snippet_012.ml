Review open security reports
