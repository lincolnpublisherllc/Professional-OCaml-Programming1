### Minimal repro
