opam lock, dune profiles, make dev for quick spins.
./script/minrepro generator (copies minimal dune project).
