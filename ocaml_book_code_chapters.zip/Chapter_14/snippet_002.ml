Environment: ocamlc -vnum, dune version, OS, opam switch show, relevant package versions.
