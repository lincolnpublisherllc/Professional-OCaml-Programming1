Provide a shim module (V1_of_v2 style) or an alias path.
