opam switch create . <ocaml-version>; opam install . --deps-only --locked.
Run tests, docs, and linters: dune build @all @runtest @doc.
