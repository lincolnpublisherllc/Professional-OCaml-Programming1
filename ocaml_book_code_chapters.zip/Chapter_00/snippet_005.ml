One concurrency model per module. If a module uses Eio, it does not spin Lwt promises inside hot paths. If a function is CPU-bound, we keep it pure and offload with Domainslib.
