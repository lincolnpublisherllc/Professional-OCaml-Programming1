Chapters 13–15 focus on team practice, open source, and a practical adoption roadmap for an organization.
