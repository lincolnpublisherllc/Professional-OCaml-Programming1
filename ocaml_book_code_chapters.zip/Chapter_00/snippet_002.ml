Designing stable surfaces. You will learn to carve a clean domain core, define small signatures at boundaries, and use modules to keep choices open without adding ceremony.
Structured concurrency and parallelism. Effects with Eio for I/O. Domains and Domainslib for CPU fan-out. Actor mailboxes for isolation and supervision. You will know when to use each, and how not to mix them.
