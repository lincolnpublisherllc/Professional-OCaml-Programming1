A download page will open in your browser.
