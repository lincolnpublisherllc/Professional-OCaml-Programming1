For Eio: wrap fiber entrypoints to log exceptions with the span/route.
