let parse =
  Landmarks.wrap "parse" (fun buf -> (* ... *))
