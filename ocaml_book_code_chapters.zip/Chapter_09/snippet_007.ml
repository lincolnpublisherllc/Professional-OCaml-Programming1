Effects (Eio) and promises (Lwt/Async) change where backtraces point and how to reason about concurrency.
