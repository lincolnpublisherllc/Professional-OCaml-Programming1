let%test_unit "parse alloc budget" =
  let s0 = Gc.quick_stat () in
  ignore (Parser.parse_file "fixtures/200k.csv");
  let s1 = Gc.quick_stat () in
  assert (s1.minor_words -. s0.minor_words < 60_000_000.0)  (* ~60 MB *)
