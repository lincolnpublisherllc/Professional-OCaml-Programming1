Build a small Field.slice type (off,len) and numeric parsers that don’t allocate.
