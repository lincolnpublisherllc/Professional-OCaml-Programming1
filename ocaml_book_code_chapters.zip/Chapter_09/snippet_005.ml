let compute =
  Landmarks.wrap "compute" (fun data -> (* ... *))
