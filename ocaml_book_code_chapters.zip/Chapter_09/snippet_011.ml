let b = Buffer.create 1024 in
