let () =
  Printexc.record_backtrace true;
  Eio_main.run @@ fun env ->
    try my_service env with ex ->
      Logs.err (fun m -> m "boom: %s\n%s" (Printexc.to_string ex) (Printexc.get_backtrace ()))
