List.map (fun x -> string_of_int x) xs |> String.concat ","
