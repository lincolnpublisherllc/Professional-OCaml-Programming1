let () =
  Memtrace.start (Memtrace.Collector.default ~record_backtraces:true ());
  at_exit (fun () -> Memtrace.stop ~filename:"run.ctf")
