  if i > 0 then Buffer.add_char b ',';
  Buffer.add_string b (string_of_int a.(i))
