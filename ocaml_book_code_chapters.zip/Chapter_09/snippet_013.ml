ppx_inline_test / Alcotest: microbench harnesses; keep them separate from unit tests.
