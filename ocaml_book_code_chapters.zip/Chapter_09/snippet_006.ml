let log_gc () =
  let s = Gc.quick_stat () in
  Logs.info (fun m -> m "minor_words=%.0f major_words=%.0f minor_collections=%d"
               s.minor_words s.major_words s.minor_collections)
