Distributions: watch p50/p95/p99 latency per route or job type. Averages hide pain.
