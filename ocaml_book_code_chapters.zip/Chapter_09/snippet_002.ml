module Timer = struct
  let time f =
    let t0 = Mtime_clock.now () in
    Fun.protect ~finally:(fun () ->
      let dt = Mtime.(Span.to_ms (span t0 (Mtime_clock.now ()))) in
      Logs.info (fun m -> m "ms=%.1f" dt)) f
