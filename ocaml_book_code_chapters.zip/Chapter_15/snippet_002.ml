Operational fit: with Eio for I/O and Domainslib for CPU, you can build fast services that stay readable.
