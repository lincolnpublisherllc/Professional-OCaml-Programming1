Functors and first-class modules let you swap back-ends and policies with minimal glue.
