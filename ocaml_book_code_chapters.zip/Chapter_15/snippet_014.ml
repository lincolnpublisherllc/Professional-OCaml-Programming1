Actor demo: mailbox, supervisor, and bounded queues with Eio.
