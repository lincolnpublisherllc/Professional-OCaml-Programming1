Composability: fibers for I/O, domains for CPU, actors for isolation. One model per module avoids foot-guns.
