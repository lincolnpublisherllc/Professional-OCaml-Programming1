Eio docs and examples: structured concurrency, cancellation, resource scoping.
