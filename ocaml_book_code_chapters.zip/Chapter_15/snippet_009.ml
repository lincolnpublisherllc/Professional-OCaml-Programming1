Eio server for HTTP ingestion and report APIs.
