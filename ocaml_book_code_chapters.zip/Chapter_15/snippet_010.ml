Comfortable with modules, effects (Eio), typed errors.
