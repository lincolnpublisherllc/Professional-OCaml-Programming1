Create a service skeleton: Eio server, Domainslib pool, ports/adapters, metrics, health/ready, CI with tests and docs.
