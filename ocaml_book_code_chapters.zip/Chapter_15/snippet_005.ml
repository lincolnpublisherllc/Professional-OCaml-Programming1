Week 1: language tour, module system, tooling (Merlin, dune, opam, ocamlformat).
Week 2: effects + Eio, Domainslib basics; small service skeleton.
