Toolchain: ocaml 5.x, dune, opam lockfiles, ocamlformat, Merlin/ocamllsp.
Concurrency: Eio for I/O, Domainslib for CPU, actor mailboxes for stateful components.
