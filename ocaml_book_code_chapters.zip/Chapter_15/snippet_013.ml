Eio (effects runtime patterns), dune (build system architecture), opam (package manager),
