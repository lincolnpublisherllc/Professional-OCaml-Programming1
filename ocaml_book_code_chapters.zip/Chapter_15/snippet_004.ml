Use Eio for servers, Domainslib for CPU fan-out, and actor mailboxes for stateful boundaries.
