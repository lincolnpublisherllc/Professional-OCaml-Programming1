Introduces domain DSLs; mentors on type-driven design and observability.
