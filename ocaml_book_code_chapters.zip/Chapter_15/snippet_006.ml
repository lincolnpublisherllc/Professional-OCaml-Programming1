IC5+: shapes concurrency models across services, sets performance guardrails, mentors on type-driven design and effects.
