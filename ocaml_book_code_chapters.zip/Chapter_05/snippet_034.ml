let () = Eio_main.run @@ fun env ->
  let module Alert = Alert_logs in
  let module Metrics = Metrics_prometheus in
  let module Engine = Acme_domain.Engine.Make(Alert)(Metrics) in
  let cfg = Cfg.load_exn () in
  let module P = (val Plugin_registry.lookup cfg.pricer : PRICER) in
  Http_eio.serve ~env ~routes:[
    get "/healthz" (fun _ -> `Ok "ok");
    post "/compute" (fun req ->
      let pos = Json.decode_position (Request.body req) in
      match Engine.compute (P.price pos) with
      | Ok r -> `Json (Report.to_json r)
      | Error (`Invalid e) -> `Bad_request e
      | Error (`External e) -> `Service_unavailable e)
  ]
