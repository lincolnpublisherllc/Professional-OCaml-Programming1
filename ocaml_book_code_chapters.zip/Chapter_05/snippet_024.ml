type ctx = { trace_id : string; span_id : string option }
