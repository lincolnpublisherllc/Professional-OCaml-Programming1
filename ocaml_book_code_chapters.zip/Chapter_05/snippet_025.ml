let with_span ctx name f =
  let ctx' = { ctx with span_id = Some (Uuidm.v4_gen (Random.State.make [| |]) () |> Uuidm.to_string) } in
  Metrics.time ("span_"^name) (fun () -> f ctx')
