module type PRICER = sig val price : Domain.Order.t -> float end
