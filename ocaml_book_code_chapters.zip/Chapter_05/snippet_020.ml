let load_file path : (Yojson.Safe.t, string) result = (* ... *)
let env k = Sys.getenv_opt k
