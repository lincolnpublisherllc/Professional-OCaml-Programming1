  acme.domain/           (* public library *)
    dune
    price.mli price.ml
    position.mli position.ml
    engine.mli engine.ml
  acme.ports/            (* public signatures *)
    dune
    clock.mli store.mli alert.mli metrics.mli
  acme.adapters.eio/     (* runtime 1 *)
    dune
    http_eio.ml metrics_prom.ml
  acme.adapters.lwt/     (* runtime 2 *)
    dune
    http_lwt.ml metrics_statsd.ml
  acme.plugins.fixed/    (* plugin sample *)
    dune
    pricer_fixed.ml
