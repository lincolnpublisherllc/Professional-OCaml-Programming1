module type S_v1 = sig
  type t
  val connect : Uri.t -> t
  val get : t -> key:string -> string option
