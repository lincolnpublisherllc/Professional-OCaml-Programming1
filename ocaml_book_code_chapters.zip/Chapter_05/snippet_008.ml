(* domain/engine.ml *)
module Make (A : Alert.S) = struct
  let run pos =
    if Position.excess pos then A.critical "margin breach"
