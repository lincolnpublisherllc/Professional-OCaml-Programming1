module V1_of_v2 (X : S_v2) : S_v1 = struct
  type t = X.t
  let connect u = match X.connect u with Ok t -> t | Error _ -> invalid_arg "connect"
  let get t ~key = match X.get t ~key with Ok v -> Some v | Error _ -> None
