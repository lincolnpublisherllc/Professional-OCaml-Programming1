Make configuration typed and validated; never let strings seep into logic.
