(* Runtime plugin selection for pricers *)
let pricer_of_name name : (module PRICER) =
  match name with
  | "fixed" -> (module Pricer_fixed)
  | _ -> invalid_arg "unknown pricer"
5.7.3 Service composition (Eio)
(* apps/svc/main.ml *)
open Eio
