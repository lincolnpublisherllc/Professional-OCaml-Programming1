type mode = Fast | Safe
type cfg = {
  host : string;
  port : int;
  db_uri : Uri.t;
  mode : mode;
  plugins : string list;
