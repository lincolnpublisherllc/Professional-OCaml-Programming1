(* ports/alert.mli *)
module type S = sig val warn : string -> unit val critical : string -> unit end
