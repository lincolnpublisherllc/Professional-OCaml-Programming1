  svc/                   (* service wiring, thin *)
    dune
    main.ml
