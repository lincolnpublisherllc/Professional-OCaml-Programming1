Adapters: concrete implementations of ports for a runtime (Postgres via Caqti, Eio/Lwt HTTP).
