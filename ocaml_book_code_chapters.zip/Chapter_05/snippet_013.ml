let register name impl = Hashtbl.replace registry name impl
