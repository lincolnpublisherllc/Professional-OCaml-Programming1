type cfg_err = [ `Missing of string | `Bad_uri of string | `Bad_value of string ]
