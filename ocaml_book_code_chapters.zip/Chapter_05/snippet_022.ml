let log_request ~req_id ~route ~status ~ms =
  Logs.info (fun m -> m "route=%s req_id=%s status=%d ms=%d"
               route req_id status ms)
