(* adapters/ext_prices_acl.ml *)
let to_domain (row : Ext.Row.t) : (Domain.Price.daily, [> `Decode of string]) result =
  match row.sym, row.close, row.date with
  | Some s, Some px, Some d when px >= 0. && String.for_all Char.Ascii.is_alphanum s ->
      Ok { sym = String.uppercase_ascii s; close = px; date = d }
  | _ -> Error (`Decode "missing or invalid fields")
