module type S_v2 = sig
  type t
  type err = [ `Conn of string | `Not_found ]
  val connect : Uri.t -> (t, err) result
  val get : t -> key:string -> (string, err) result
