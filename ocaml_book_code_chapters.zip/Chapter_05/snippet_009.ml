module Log_alert : Alert.S = struct
  let warn s = Logs.warn (fun m -> m "%s" s)
  let critical s = Logs.err (fun m -> m "%s" s)
