(* acme.domain/engine.mli *)
module type S = sig
  type pos
  type report
  type err = [ `Invalid of string | `External of string ]
  val compute : pos -> (report, err) result
