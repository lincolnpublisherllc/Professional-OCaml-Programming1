let registry : (string, (module PRICER)) Hashtbl.t = Hashtbl.create 8
