(* ports/store.mli *)
module type S = sig
  type t
  type err = [ `Conn of string | `Sql of string | `Decode of string ]
  val connect : Uri.t -> (t, err) result
  val get_closes : t -> date:int -> (float Domain.Price.sym_map, err) result
  val put_trades : t -> Domain.Trade.t list -> (unit, err) result
