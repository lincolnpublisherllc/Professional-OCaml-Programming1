Swapping Eio ↔ Lwt requires no changes in acme.domain.
