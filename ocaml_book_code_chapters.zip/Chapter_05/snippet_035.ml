Objective
Refactor a working app into: a stable domain library, two runtime adapters (Eio + Lwt), and a plugin slot selected by a feature flag. Ship a CLI and service that both consume the same domain core.
