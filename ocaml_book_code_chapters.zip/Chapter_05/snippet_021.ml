let parse (json:Yojson.Safe.t option) : (cfg, cfg_err) result =
  let open Result in
  let host = (* file/env/default *) Ok "0.0.0.0" in
  let port = Ok 8080 in
  let db_uri = Uri.of_string "postgres://..." |> Result.ok in
  let mode = Ok Safe in
  let plugins = Ok ["fixed"] in
  Result.bind host (fun host ->
  Result.bind port (fun port ->
  Result.bind db_uri (fun db_uri ->
  Result.bind mode (fun mode ->
  Result.map (fun plugins -> {host;port;db_uri;mode;plugins}) plugins ))))
