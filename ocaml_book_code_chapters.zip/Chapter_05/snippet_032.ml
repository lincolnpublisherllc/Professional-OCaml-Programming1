  let compute p =
    M.time "engine_compute" (fun () ->
      match Domain.Position.validate p with
      | Error e -> A.warn ("invalid position: "^e); Error (`Invalid e)
      | Ok () ->
        let r = Domain.Report.of_position p in
        if Domain.Report.too_risky r then A.warn "high risk";
        Ok r)
