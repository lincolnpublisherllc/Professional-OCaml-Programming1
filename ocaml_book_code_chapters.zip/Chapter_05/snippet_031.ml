(* acme.domain/engine.ml *)
module Make (A: Alert.S) (M: Metrics.S) = struct
  type pos = Domain.Position.t
  type report = Domain.Report.t
  type err = [ `Invalid of string | `External of string ]
