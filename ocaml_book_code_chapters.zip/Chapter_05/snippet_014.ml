let pricer_of name =
  match Hashtbl.find_opt registry name with
  | Some m -> m
  | None -> invalid_arg ("unknown pricer: "^name)
