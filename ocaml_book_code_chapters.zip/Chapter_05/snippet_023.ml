module type METRIC = sig
  val inc  : string -> unit
  val time : string -> (unit -> 'a) -> 'a
