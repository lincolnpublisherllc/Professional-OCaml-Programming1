5.6 Putting it together: reference layout (dune)
