Adapters depend outward (Eio/Lwt/Caqti/Prometheus).
