Mixing Lwt and Eio inside hot handlers caused subtle stalls. Fix: isolate interop; one model per module.
