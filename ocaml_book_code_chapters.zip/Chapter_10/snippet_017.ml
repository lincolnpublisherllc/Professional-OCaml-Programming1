Determinism: metrics increments match routed decisions; logs contain stable, parseable fields.
