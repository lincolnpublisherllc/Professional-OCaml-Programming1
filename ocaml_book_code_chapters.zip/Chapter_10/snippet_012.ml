tenant_id -> actor with bounded mailbox (Eio streams or SPSC ring).
