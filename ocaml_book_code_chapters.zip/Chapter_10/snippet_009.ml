Staffing: pair newcomers with “type design” reviews early; start on adapters before core IR/engine. A week of module system exercises pays off.
