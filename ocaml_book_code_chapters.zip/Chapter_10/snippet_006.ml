Workers: CPU work (checksum, small transforms) via Domainslib; I/O via Eio with timeouts.
