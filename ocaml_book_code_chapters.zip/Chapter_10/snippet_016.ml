Metrics & observability: Prometheus endpoint; structured logs with tenant, type, ms.
Soak test: synthetic load at 200k msgs/min, 4 tenants; verify p99 and drop rates match policy.
