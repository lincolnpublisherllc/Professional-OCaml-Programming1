Ingestion: bounded Eio pipelines parse CSV/JSONL using bigarrays; idempotency keys deduplicate per file chunk.
