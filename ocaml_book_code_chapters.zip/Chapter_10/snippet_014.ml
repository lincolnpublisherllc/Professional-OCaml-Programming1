gateway_messages_total{type,tenant}
