HTTP client (Eio)
