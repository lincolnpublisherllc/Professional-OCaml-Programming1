Listeners: Eio sockets; each connection handled by a fiber supervised under a Switch.
