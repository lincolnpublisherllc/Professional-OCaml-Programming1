Frame: [len:u32][tenant:u32][type:u8][payload:bytes]
