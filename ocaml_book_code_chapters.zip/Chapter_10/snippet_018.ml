One concurrency model per module: Eio for I/O, Domainslib for CPU, actors to structure.
