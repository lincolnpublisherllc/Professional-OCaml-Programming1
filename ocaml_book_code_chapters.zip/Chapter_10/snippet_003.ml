GADT safety: type _ expr = … ensures only normalized forms reach codegen; impossible states disappear.
Plugins: extensible variants for new lint rules. First-class module registry for dynamic enable/disable.
