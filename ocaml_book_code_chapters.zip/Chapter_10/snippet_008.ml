Packaging: dune profiles target xen/hvt with minimal dependencies.
