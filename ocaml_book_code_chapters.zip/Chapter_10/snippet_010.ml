Ecosystem: prefer well-maintained libs (Eio, Caqti, cmdliner, ppxlib, bigstringaf). Keep vendor shims thin and replaceable.
