A small, stable .mli around the core IR let multiple teams add passes independently.
