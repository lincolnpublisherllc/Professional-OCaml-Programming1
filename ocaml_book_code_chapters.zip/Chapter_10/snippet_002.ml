Back-end: effectful codegen using Eio for filesystem/network I/O; CPU-heavy optimization via Domainslib.
